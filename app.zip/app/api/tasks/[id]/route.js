import { NextResponse } from "next/server";
import clientPromise from "@/lib/mongodb";
import { ObjectId } from "mongodb";

/**
 * Handle Task Updates (Editing & Status Toggling)
 * Method: PATCH /api/tasks/[id]
 */
export async function PATCH(req, { params }) {
  try {
    const { id } = params;
    const updates = await req.json();
    
    const client = await clientPromise;
    const db = client.db("mindsync");

    // Remove _id from updates if it exists to prevent MongoDB errors
    if (updates._id) delete updates._id;

    const result = await db.collection("tasks").updateOne(
      { _id: new ObjectId(id) },
      { $set: updates }
    );

    if (result.matchedCount === 0) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Task Update Error:", error);
    return NextResponse.json({ error: "Failed to update task" }, { status: 500 });
  }
}

/**
 * Handle Task Deletion
 * Method: DELETE /api/tasks/[id]
 */
export async function DELETE(req, { params }) {
  try {
    const { id } = params;
    
    const client = await clientPromise;
    const db = client.db("mindsync");

    const result = await db.collection("tasks").deleteOne({
      _id: new ObjectId(id)
    });

    if (result.deletedCount === 0) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Task Delete Error:", error);
    return NextResponse.json({ error: "Failed to delete task" }, { status: 500 });
  }
}