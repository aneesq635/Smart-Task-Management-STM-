"use client";

import React, { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../components/AuthContext";
import supabase from "../components/supabase";
import { logBehavior } from "@/lib/telemetry.js";
import {
  Brain,
  LayoutDashboard,
  CalendarCheck,
  MessageSquare,
  BarChart3,
  Settings,
  LogOut,
  Moon,
  Sun,
  User,
  Smile,
  Meh,
  Frown,
  Send,
  X,
  Plus,
  Loader2,
  ShieldAlert,
  Zap,
  CheckCircle2,
  Trash2,
  Edit3,
  Check,
} from "lucide-react";

export default function DashboardPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  const [firstName, setFirstName] = useState("User");
  const [isDark, setIsDark] = useState(false);
  const [mood, setMood] = useState(null);
  const [chatInput, setChatInput] = useState("");
  const [aiOpen, setAiOpen] = useState(false);

  /* --- DATA STATES --- */
  const [tasks, setTasks] = useState([]);
  const [userProfile, setUserProfile] = useState(null);
  const [dataLoading, setDataLoading] = useState(true);
  const [showAddTask, setShowAddTask] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState("");

  /* --- HYBRID INTELLIGENCE LOGIC --- */
  const isGenerallySensitive = userProfile?.traits?.stressSensitivity > 3;
  const isFeelingLow = mood === "low";
  const activeTasks = tasks.filter((t) => t.status !== "Completed");
  const isOverloaded = activeTasks.length >= 5;

  // Adaptive Mode Logic
  const shouldActivateSupport = isFeelingLow || (isGenerallySensitive && mood !== "good") || isOverloaded;

  /* 🔐 AUTH + ONBOARDING PROTECTION */
  useEffect(() => {
    const protect = async () => {
      const { data } = await supabase.auth.getUser();
      if (!data?.user) {
        router.replace("/");
        return;
      }

      if (!data.user.user_metadata?.has_completed_questionnaire) {
        router.replace("/onboarding");
      } else {
        logBehavior(data.user.id, "session_start", "dashboard_load");
      }
    };
    protect();

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) router.replace("/");
    });

    return () => listener.subscription.unsubscribe();
  }, [router]);

  /* --- FETCH CORE DATA --- */
  const fetchData = useCallback(async () => {
    if (!user?.id) return;
    try {
      setDataLoading(true);
      const [taskRes, profileRes] = await Promise.all([
        fetch(`/api/tasks?userId=${user.id}`),
        fetch(`/api/profile?userId=${user.id}`)
      ]);

      if (taskRes.ok) setTasks(await taskRes.json());
      if (profileRes.ok) setUserProfile(await profileRes.json());
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setDataLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    if (!loading && !user) router.replace("/");
    if (user) {
      setFirstName(user.user_metadata?.first_name || "User");
      fetchData();
    }
  }, [user, loading, router, fetchData]);

  /* --- MOOD LOGGING --- */
  const handleMoodSelect = async (selectedMood) => {
    setMood(selectedMood);
    logBehavior(user.id, "mood_check", selectedMood);

    try {
      await fetch("/api/mood", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          mood: selectedMood,
          note: "Dashboard Quick-check"
        }),
      });
    } catch (e) {
      console.error("Mood sync failed", e);
    }
  };

  /* --- TASK ACTIONS (CRUD) --- */
  const handleAddTask = async (e, customTitle = null) => {
    if (e) e.preventDefault();
    const title = customTitle || newTaskTitle;
    if (!title.trim()) return;

    const creationState = shouldActivateSupport ? "supportive_mode" : "standard_mode";

    try {
      const res = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          title: title,
          energyLevel: shouldActivateSupport ? "Low" : "Medium",
          complexity: shouldActivateSupport ? 1 : 3,
          psychologicalTag: shouldActivateSupport ? "Micro-step" : "Quick Win",
        }),
      });

      if (res.ok) {
        logBehavior(user.id, "task_create", creationState);
        setNewTaskTitle("");
        setShowAddTask(false);
        fetchData(); 
      }
    } catch (error) {
      console.error("Error adding task:", error);
    }
  };

  const handleUpdateTask = async (taskId, updates) => {
    try {
      const res = await fetch(`/api/tasks/${taskId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      if (res.ok) {
        setTasks(prev => prev.map(t => t._id === taskId ? { ...t, ...updates } : t));
        logBehavior(user.id, "task_update", taskId);
      }
    } catch (error) {
      console.error("Update failed", error);
    }
  };

  const handleDeleteTask = async (taskId) => {
    try {
      const res = await fetch(`/api/tasks/${taskId}`, { method: "DELETE" });
      if (res.ok) {
        setTasks(prev => prev.filter(t => t._id !== taskId));
        logBehavior(user.id, "task_delete", taskId);
      }
    } catch (error) {
      console.error("Delete failed", error);
    }
  };

  /* THEME SYNC */
  useEffect(() => {
    setIsDark(document.documentElement.classList.contains("dark"));
  }, []);

  const toggleTheme = () => {
    document.documentElement.classList.toggle("dark");
    setIsDark((prev) => !prev);
    if (user) logBehavior(user.id, "ui_toggle", isDark ? "light_mode" : "dark_mode");
  };

  const handleLogout = async () => {
    if (user) logBehavior(user.id, "auth_logout");
    await supabase.auth.signOut();
    router.replace("/");
  };

  if (loading || dataLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Brain className="w-10 h-10 animate-pulse text-indigo-600" />
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-slate-900 transition-colors">
      {/* SIDEBAR */}
      <aside className="w-64 fixed left-0 top-0 bottom-0 bg-white dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 p-6 hidden lg:flex flex-col z-30">
        <div className="flex items-center gap-2 mb-10">
          <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center">
            <Brain className="text-white w-5 h-5" />
          </div>
          <span className="font-bold text-xl text-slate-900 dark:text-white">MindSync</span>
        </div>

        <nav className="space-y-1 flex-1">
          <SidebarItem icon={<LayoutDashboard />} label="Dashboard" active />
          <SidebarItem icon={<CalendarCheck />} label="Today’s Plan" />
          <SidebarItem 
            icon={<MessageSquare />} 
            label="Talk to AI" 
            onClick={() => {
                setAiOpen(true);
                logBehavior(user.id, "ai_interact", "sidebar_open");
            }} 
          />
          <SidebarItem icon={<BarChart3 />} label="Insights" disabled />
          <SidebarItem icon={<Settings />} label="Settings" />
        </nav>

        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-red-600 rounded-xl transition-colors"
        >
          <LogOut className="w-5 h-5" /> Logout
        </button>
      </aside>

      {/* MAIN */}
      <main className="flex-1 ml-0 lg:ml-64 flex flex-col">
        {/* TOP BAR */}
        <header className="h-20 fixed top-0 left-0 right-0 lg:left-64 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-8 flex items-center justify-between z-20">
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              {shouldActivateSupport ? "Take it easy, " : "Good evening, "}{firstName}
            </h1>
            <p className="text-sm text-slate-500">
              {isFeelingLow ? "I'm here to support you. Let's keep things very simple." : 
               isOverloaded ? "You've got a lot on your plate. Focus on one small win." :
               "Let’s keep today light and manageable."}
            </p>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={toggleTheme}
              className="w-11 h-11 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-center hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
            >
              {isDark ? <Sun className="text-yellow-400" /> : <Moon className="text-slate-600" />}
            </button>
            <User className="w-10 h-10 text-slate-400" />
          </div>
        </header>

        {/* CONTENT */}
        <section className="pt-24 px-8 space-y-10 overflow-y-auto flex-1 pb-10">
          
          {/* SUPPORTIVE BANNER */}
          {shouldActivateSupport && (
            <div className="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800 p-4 rounded-2xl flex items-center gap-4 animate-in fade-in slide-in-from-top-4">
              <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/50 rounded-xl flex items-center justify-center text-indigo-600">
                <ShieldAlert size={20} />
              </div>
              <p className="text-sm text-indigo-800 dark:text-indigo-200 font-medium">
                {isFeelingLow ? "Supportive Mode Active: Tasks will be broken into micro-steps." : "High Workload Detected: I've prioritized low-energy wins for you."}
              </p>
            </div>
          )}

          {/* TODAY OVERVIEW */}
          <div className="bg-white dark:bg-slate-950 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 flex justify-between items-center shadow-sm">
            <div className="flex items-center gap-6">
              <div>
                <h2 className="font-bold text-lg text-slate-900 dark:text-white">Today's Focus</h2>
                <p className="text-slate-500 text-sm">{activeTasks.length} active items</p>
              </div>
              {shouldActivateSupport && (
                <button 
                  onClick={() => handleAddTask(null, "5-minute mindful breathing")}
                  className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-300 rounded-full text-xs font-bold border border-indigo-100 dark:border-indigo-800 hover:scale-105 transition-all"
                >
                  <Zap size={12} fill="currentColor" /> Suggestion: 5m Breathing
                </button>
              )}
            </div>
            <button
              onClick={() => setShowAddTask(true)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl flex items-center gap-2 transition-all"
            >
              <Plus size={18} /> Add Task
            </button>
          </div>

          {/* ADD TASK FORM */}
          {showAddTask && (
            <form onSubmit={handleAddTask} className="bg-white dark:bg-slate-900 p-4 rounded-2xl border-2 border-indigo-500 shadow-xl animate-in zoom-in-95">
              <input
                autoFocus
                value={newTaskTitle}
                onChange={(e) => setNewTaskTitle(e.target.value)}
                placeholder="What needs to be done?"
                className="w-full bg-transparent border-none outline-none text-lg text-slate-900 dark:text-white placeholder:text-slate-400"
              />
              <div className="flex justify-between items-center mt-4">
                <span className="text-[10px] text-indigo-500 font-bold uppercase tracking-widest flex items-center gap-1">
                  <Zap size={12} /> {shouldActivateSupport ? "AI: Auto-simplifying" : "AI: Optimal energy set"}
                </span>
                <div className="flex gap-2">
                  <button type="button" onClick={() => setShowAddTask(false)} className="px-3 py-1 text-sm text-slate-500">Cancel</button>
                  <button type="submit" className="px-4 py-1 text-sm bg-indigo-600 text-white rounded-lg">Create</button>
                </div>
              </div>
            </form>
          )}

          {/* TASK GRID */}
          <div className="grid gap-4 md:grid-cols-3">
            {tasks.length > 0 ? (
              tasks.map((task) => (
                <FocusCard
                  key={task._id}
                  task={task}
                  onUpdate={(updates) => handleUpdateTask(task._id, updates)}
                  onDelete={() => handleDeleteTask(task._id)}
                />
              ))
            ) : (
              <div className="col-span-full py-10 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl">
                <p className="text-slate-400 italic">No tasks yet. Add one above!</p>
              </div>
            )}
          </div>

          {/* EMOTIONAL CHECK-IN */}
          <div className="bg-white dark:bg-slate-950 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 text-center">
            <h2 className="font-bold text-xl mb-6 text-slate-900 dark:text-white">
              How are you feeling right now?
            </h2>
            <div className="flex justify-center gap-8">
              <MoodIcon icon={<Smile />} active={mood === "good"} label="Good" onClick={() => handleMoodSelect("good")} />
              <MoodIcon icon={<Meh />} active={mood === "okay"} label="Okay" onClick={() => handleMoodSelect("okay")} />
              <MoodIcon icon={<Frown />} active={mood === "low"} label="Low" onClick={() => handleMoodSelect("low")} />
            </div>
          </div>
        </section>
      </main>

      {/* FLOATING AI BRAIN */}
      <button
        onClick={() => {
            setAiOpen(true);
            logBehavior(user.id, "ai_interact", "floating_button");
        }}
        className="fixed bottom-8 right-8 w-16 h-16 rounded-full bg-indigo-600 text-white shadow-2xl hover:scale-110 transition-all flex items-center justify-center z-40"
      >
        <Brain size={30} className={shouldActivateSupport ? "animate-pulse" : ""} />
      </button>

      {/* AI CHAT PANEL */}
      {aiOpen && (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 flex justify-end">
          <div className="w-full sm:w-96 bg-white dark:bg-slate-950 h-full flex flex-col shadow-2xl animate-in slide-in-from-right">
            <div className="h-16 px-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="font-bold text-slate-900 dark:text-white">Your AI Companion</div>
              <button onClick={() => setAiOpen(false)} className="text-slate-500 hover:text-slate-700">
                <X />
              </button>
            </div>

            <div className="flex-1 p-4 overflow-y-auto text-sm text-slate-500">
                {shouldActivateSupport ? "I've noticed you might be feeling a bit under pressure. I'm here to help you simplify things." : "I’m here to listen. 💬"}
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex gap-2">
              <input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="What’s on your mind?"
                className="flex-1 h-11 rounded-xl px-4 border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-indigo-500"
              />
              <button className="w-11 h-11 bg-indigo-600 rounded-xl flex items-center justify-center text-white hover:bg-indigo-700 transition-colors">
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- COMPONENTS ---------- */

const SidebarItem = ({ icon, label, active, disabled, onClick }) => (
  <div
    onClick={onClick}
    className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-colors ${
      active
        ? "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 font-bold"
        : disabled
        ? "text-slate-300 dark:text-slate-700 cursor-not-allowed opacity-40"
        : "text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-900 hover:text-slate-900 dark:hover:text-white"
    }`}
  >
    {React.cloneElement(icon, { size: 20 })}
    {label}
  </div>
);

const FocusCard = ({ task, onUpdate, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(task.title);

  const handleSave = () => {
    if (editTitle.trim() && editTitle !== task.title) {
      onUpdate({ title: editTitle });
    }
    setIsEditing(false);
  };

  const isCompleted = task.status === "Completed";

  return (
    <div className={`bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 transition-all shadow-sm group relative ${isCompleted ? 'opacity-60' : 'hover:border-indigo-500/50'}`}>
      <div className="flex justify-between items-start mb-3">
        <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase ${task.energyLevel === "Low" ? "bg-green-100 text-green-600" : "bg-blue-100 text-blue-600"}`}>
          {task.energyLevel} Energy
        </span>
        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
          {!isCompleted && <button onClick={() => setIsEditing(!isEditing)} className="text-slate-400 hover:text-indigo-600"><Edit3 size={14}/></button>}
          <button onClick={onDelete} className="text-slate-400 hover:text-red-500"><Trash2 size={14}/></button>
        </div>
      </div>

      {isEditing ? (
        <div className="flex gap-2">
          <input 
            value={editTitle} 
            onChange={(e) => setEditTitle(e.target.value)}
            className="flex-1 bg-slate-50 dark:bg-slate-900 rounded px-2 py-1 text-sm outline-none border border-indigo-500"
            autoFocus
          />
          <button onClick={handleSave} className="text-green-500"><Check size={18}/></button>
        </div>
      ) : (
        <h3 className={`font-bold text-slate-800 dark:text-white leading-tight transition-colors ${isCompleted ? 'line-through' : 'group-hover:text-indigo-600'}`}>
          {task.title}
        </h3>
      )}

      <div className="mt-4 flex justify-between items-center">
        <span className="text-[9px] text-slate-400 font-medium uppercase tracking-wider">{task.psychologicalTag || "Quick Win"}</span>
        <button 
          onClick={() => onUpdate({ status: isCompleted ? "In Progress" : "Completed" })}
          className={`p-1.5 rounded-lg transition-colors ${isCompleted ? 'bg-green-500 text-white' : 'bg-slate-50 dark:bg-slate-900 text-slate-300 hover:text-green-500'}`}
        >
          <CheckCircle2 size={18} />
        </button>
      </div>
    </div>
  );
};

const MoodIcon = ({ icon, active, onClick, label }) => (
  <button
    onClick={onClick}
    className="group flex flex-col items-center gap-2"
  >
    <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all duration-300 border ${
      active
        ? "bg-indigo-600 text-white scale-110 shadow-xl border-indigo-600"
        : "bg-slate-50 dark:bg-slate-800 text-slate-400 border-transparent hover:border-indigo-400 shadow-sm"
    }`}>
      {React.cloneElement(icon, { size: 32 })}
    </div>
    {label && <span className={`text-xs font-bold transition-colors ${active ? "text-indigo-600" : "text-slate-400 group-hover:text-slate-600"}`}>{label}</span>}
  </button>
);

// "use client";

// import React, { useEffect, useState, useCallback } from "react";
// import { useRouter } from "next/navigation";
// import { useAuth } from "../components/AuthContext";
// import supabase from "../components/supabase";
// import {
// Brain,
// LayoutDashboard,
// CalendarCheck,
// MessageSquare,
// BarChart3,
// Settings,
// LogOut,
// Moon,
// Sun,
// User,
// Smile,
// Meh,
// Frown,
// Send,
// X,
// Plus,
// Loader2
// } from "lucide-react";

// export default function DashboardPage() {
// const { user, loading } = useAuth();
// const router = useRouter();

// const [firstName, setFirstName] = useState("User");
// const [isDark, setIsDark] = useState(false);
// const [mood, setMood] = useState(null);
// const [chatInput, setChatInput] = useState("");
// const [aiOpen, setAiOpen] = useState(false);

// /_ --- NEW STATES FOR PHASE 1 --- _/
// const [tasks, setTasks] = useState([]);
// const [tasksLoading, setTasksLoading] = useState(true);
// const [showAddTask, setShowAddTask] = useState(false);
// const [newTaskTitle, setNewTaskTitle] = useState("");

// /_ 🔐 AUTH + ONBOARDING PROTECTION _/
// useEffect(() => {
// const protect = async () => {
// const { data } = await supabase.auth.getUser();
// if (!data?.user) {
// router.replace("/");
// return;
// }

//       if (!data.user.user_metadata?.has_completed_questionnaire) {
//         router.replace("/onboarding");
//       }
//     };

//     protect();

//     const { data: listener } = supabase.auth.onAuthStateChange(
//       (_event, session) => {
//         if (!session) {
//           router.replace("/");
//         }
//       }
//     );

//     return () => listener.subscription.unsubscribe();

// }, [router]);

// /_ --- FUNCTION: FETCH TASKS (GET) --- _/
// const fetchTasks = useCallback(async () => {
// if (!user?.id) return;
// try {
// setTasksLoading(true);
// const res = await fetch(`/api/tasks?userId=${user.id}`);
// const data = await res.json();
// if (res.ok) {
// setTasks(data);
// }
// } catch (error) {
// console.error("Error fetching tasks:", error);
// } finally {
// setTasksLoading(false);
// }
// }, [user?.id]);

// /_ --- FUNCTION: ADD TASK (POST) --- _/
// const handleAddTask = async (e) => {
// e.preventDefault();
// if (!newTaskTitle.trim()) return;

//     try {
//       const res = await fetch("/api/tasks", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           userId: user.id,
//           title: newTaskTitle,
//           energyLevel: "Medium", // Default for now
//           complexity: 3,         // Default for now
//           psychologicalTag: "Quick Win", // Default for now
//         }),
//       });

//       if (res.ok) {
//         setNewTaskTitle("");
//         setShowAddTask(false);
//         fetchTasks(); // Refresh list
//       }
//     } catch (error) {
//       console.error("Error adding task:", error);
//     }

// };

// /_ INITIAL DATA LOAD _/
// useEffect(() => {
// if (!loading && !user) router.replace("/");
// if (user) {
// setFirstName(user.user_metadata?.first_name || "User");
// fetchTasks();
// }
// }, [user, loading, router, fetchTasks]);

// /_ THEME SYNC _/
// useEffect(() => {
// setIsDark(document.documentElement.classList.contains("dark"));
// }, []);

// const toggleTheme = () => {
// document.documentElement.classList.toggle("dark");
// setIsDark((p) => !p);
// };

// const handleLogout = async () => {
// await supabase.auth.signOut();
// router.replace("/");
// };

// if (loading) {
// return (

// <div className="min-h-screen flex items-center justify-center">
// <Brain className="w-10 h-10 animate-pulse text-indigo-600" />
// </div>
// );
// }

// if (!user) return null;

// return (

// <div className="min-h-screen flex bg-slate-50 dark:bg-slate-900 transition-colors">

//       {/* SIDEBAR */}
//       <aside className="w-64 fixed left-0 top-0 bottom-0 bg-white dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 p-6 hidden lg:flex flex-col z-30">
//         <div className="flex items-center gap-2 mb-10">
//           <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center">
//             <Brain className="text-white w-5 h-5" />
//           </div>
//           <span className="font-bold text-xl text-slate-900 dark:text-white">MindSync</span>
//         </div>

//         <nav className="space-y-1 flex-1">
//           <SidebarItem icon={<LayoutDashboard />} label="Dashboard" active />
//           <SidebarItem icon={<CalendarCheck />} label="Today’s Plan" />
//           <SidebarItem icon={<MessageSquare />} label="Talk to AI" />
//           <SidebarItem icon={<BarChart3 />} label="Insights" disabled />
//           <SidebarItem icon={<Settings />} label="Settings" />
//         </nav>

//         <button
//           onClick={handleLogout}
//           className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-red-600 rounded-xl transition-colors"
//         >
//           <LogOut className="w-5 h-5" /> Logout
//         </button>
//       </aside>

//       {/* MAIN */}
//       <main className="flex-1 ml-0 lg:ml-64 flex flex-col">

//         {/* TOP BAR */}
//         <header className="h-20 fixed top-0 left-0 right-0 lg:left-64 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-8 flex items-center justify-between z-20">
//           <div>
//             <h1 className="text-xl font-bold text-slate-900 dark:text-white">
//               Good evening, {firstName}
//             </h1>
//             <p className="text-sm text-slate-500">
//               Let’s keep today light and manageable.
//             </p>
//           </div>

//           <div className="flex items-center gap-4">
//             <button
//               onClick={toggleTheme}
//               className="w-11 h-11 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-center hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
//             >
//               {isDark ? <Sun className="text-yellow-400" /> : <Moon className="text-slate-600" />}
//             </button>
//             <User className="w-10 h-10 text-slate-400" />
//           </div>
//         </header>

//         {/* CONTENT */}
//         <section className="pt-24 px-8 space-y-10 overflow-y-auto flex-1 pb-10">

//           {/* TODAY OVERVIEW */}
//           <div className="bg-white dark:bg-slate-950 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 flex justify-between items-center">
//             <div>
//               <h2 className="font-bold text-lg mb-1 text-slate-900 dark:text-white">Today</h2>
//               <p className="text-slate-500">You have {tasks.length} tasks in your queue.</p>
//             </div>
//             <button
//               onClick={() => setShowAddTask(true)}
//               className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl flex items-center gap-2 transition-all"
//             >
//               <Plus size={18} /> Add Task
//             </button>
//           </div>

//           {/* ADD TASK FORM (Conditional) */}
//           {showAddTask && (
//             <form onSubmit={handleAddTask} className="bg-indigo-50 dark:bg-indigo-900/10 p-4 rounded-2xl border border-indigo-100 dark:border-indigo-800 animate-in fade-in slide-in-from-top-2">
//               <input
//                 autoFocus
//                 value={newTaskTitle}
//                 onChange={(e) => setNewTaskTitle(e.target.value)}
//                 placeholder="What needs to be done?"
//                 className="w-full bg-transparent border-none outline-none text-slate-900 dark:text-white font-medium placeholder:text-slate-400"
//               />
//               <div className="flex justify-end gap-2 mt-3">
//                 <button type="button" onClick={() => setShowAddTask(false)} className="px-3 py-1 text-sm text-slate-500">Cancel</button>
//                 <button type="submit" className="px-4 py-1 text-sm bg-indigo-600 text-white rounded-lg">Save Task</button>
//               </div>
//             </form>
//           )}

//           {/* TODAY FOCUS (Now Dynamic) */}
//           <div>
//             <h2 className="font-bold mb-4 text-slate-900 dark:text-white">Today’s Focus</h2>
//             {tasksLoading ? (
//               <div className="flex justify-center p-10"><Loader2 className="animate-spin text-indigo-600" /></div>
//             ) : (
//               <div className="grid gap-4 md:grid-cols-3">
//                 {tasks.length > 0 ? (
//                   tasks.map((task) => (
//                     <FocusCard
//                       key={task._id}
//                       title={task.title}
//                       desc={task.psychologicalTag || "Task"}
//                       energy={task.energyLevel}
//                     />
//                   ))
//                 ) : (
//                   <p className="text-slate-400 text-sm italic">No tasks yet. Add one above!</p>
//                 )}
//               </div>
//             )}
//           </div>

//           {/* EMOTIONAL CHECK-IN */}
//           <div className="bg-white dark:bg-slate-950 p-6 rounded-3xl border border-slate-100 dark:border-slate-800">
//             <h2 className="font-bold mb-4 text-slate-900 dark:text-white">
//               How are you feeling right now?
//             </h2>
//             <div className="flex gap-6">
//               <MoodIcon icon={<Smile />} active={mood === "good"} onClick={() => setMood("good")} />
//               <MoodIcon icon={<Meh />} active={mood === "okay"} onClick={() => setMood("okay")} />
//               <MoodIcon icon={<Frown />} active={mood === "low"} onClick={() => setMood("low")} />
//             </div>
//           </div>
//         </section>
//       </main>

//       {/* FLOATING AI BUTTON */}
//       <button
//         onClick={() => setAiOpen(true)}
//         className="fixed bottom-8 right-8 w-16 h-16 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-xl animate-pulse hover:scale-105 transition z-40"
//         title="Talk to me"
//       >
//         <Brain />
//       </button>

//       {/* AI CHAT PANEL */}
//       {aiOpen && (
//         <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 flex justify-end">
//           <div className="w-full sm:w-96 bg-white dark:bg-slate-950 h-full flex flex-col shadow-2xl">
//             <div className="h-16 px-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
//               <div className="font-bold text-slate-900 dark:text-white">Your AI Companion</div>
//               <button onClick={() => setAiOpen(false)} className="text-slate-500 hover:text-slate-700">
//                 <X />
//               </button>
//             </div>

//             <div className="flex-1 p-4 overflow-y-auto text-sm text-slate-500">
//               I’m here to listen. 💬
//             </div>

//             <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex gap-2">
//               <input
//                 value={chatInput}
//                 onChange={(e) => setChatInput(e.target.value)}
//                 placeholder="What’s on your mind?"
//                 className="flex-1 h-11 rounded-xl px-4 border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:border-indigo-500"
//               />
//               <button className="w-11 h-11 bg-indigo-600 rounded-xl flex items-center justify-center text-white hover:bg-indigo-700 transition-colors">
//                 <Send className="w-4 h-4" />
//               </button>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>

// );
// }

// /_ ---------- COMPONENTS ---------- _/

// const SidebarItem = ({ icon, label, active, disabled }) => (

//   <div
//     className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-colors ${
//       active
//         ? "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 font-bold"
//         : disabled
//         ? "text-slate-300 dark:text-slate-700 cursor-not-allowed"
//         : "text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-900 hover:text-slate-900 dark:hover:text-white"
//     }`}
//   >
//     {React.cloneElement(icon, { size: 20 })}
//     {label}
//   </div>
// );

// const FocusCard = ({ title, desc, energy }) => (

//   <div className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-indigo-500/50 transition-colors shadow-sm">
//     <div className="flex justify-between items-start mb-2">
//       <h3 className="font-bold text-slate-900 dark:text-white">{title}</h3>
//       <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase tracking-wider font-semibold">
//         {energy}
//       </span>
//     </div>
//     <p className="text-sm text-slate-500">{desc}</p>
//   </div>
// );

// const MoodIcon = ({ icon, active, onClick }) => (
// <button
// onClick={onClick}
// className={`w-14 h-14 rounded-2xl flex items-center justify-center border transition-all duration-300 ${
//       active
//         ? "bg-indigo-600 text-white scale-110 shadow-lg shadow-indigo-200 dark:shadow-none border-indigo-600"
//         : "bg-slate-50 dark:bg-slate-800 text-slate-400 border-slate-100 dark:border-slate-700 hover:border-slate-300"
//     }`}

// >

//     {React.cloneElement(icon, { size: 28 })}

//   </button>
// );